package com.example.savethefood;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class customerMap extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customer_map);
    }
}