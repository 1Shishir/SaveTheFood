package com.example.savethefood;

import android.media.Image;
import android.net.Uri;

import java.util.ArrayList;

public class database {

    static int[] food_img={R.drawable.stf_logo,R.drawable.stf_logo,R.drawable.stf_logo,R.drawable.stf_logo,R.drawable.stf_logo,R.drawable.stf_logo};
    static String[] food_name ={"kacchi","biriwani","burger","pasta","grill","pizza"};
    static String[] food_restaurant ={"sultan's Dine","Hazi biriwani","burger king","NFC","Amania","pizza hut"};
   static String[] food_price ={"3 RM (Was 21 RM)","2 RM (Was 15 RM)","4 RM (Was 25 RM)","6 RM (Was 29 RM)","3 RM (Was 12 RM)","5 RM (Was 19 RM)"};
   static String[] food_location ={"Damansara Damai","Taman Desa Riang","Suajana Damansara","Damansara Damai","Taman Desa Riang","Suajana Damansara"};

    static int[] delivery_img={R.drawable.stf_logo,R.drawable.stf_logo,R.drawable.stf_logo};
    static String[] delivery_name ={"biriwani","pasta","pizza"};
    static String[] delivery_restaurant ={"Hazi biriwani","NFC","pizza hut"};
    static String[] delivery_price ={"3 RM (Was 21 RM)","3 RM (Was 12 RM)","5 RM (Was 19 RM)"};
    static String[] delivery_location ={"Damansara Damai","Taman Desa Riang","Suajana Damansara"};

    static int[] customer_img={R.drawable.stf_logo,R.drawable.stf_logo,R.drawable.stf_logo};
    static String[] customer_name ={"burger","pasta","grill"};
    static String[] customer_restaurant ={"burger king","NFC","Amania"};
    static String[] customer_price ={"3 RM (Was 21 RM)","3 RM (Was 12 RM)","5 RM (Was 19 RM)"};
    static String[] customer_location ={"Damansara Damai","Taman Desa Riang","Suajana Damansara"};

//    static int[] pantry_img={R.drawable.stf_logo,R.drawable.stf_logo,R.drawable.stf_logo,R.drawable.stf_logo,R.drawable.stf_logo,R.drawable.stf_logo};
//    static String[] pantry_name ={"Lettuce","Carrot","Whole Chicken","Beef","Orange","pizza"};
//    static String[] pantry_qut ={"3","12","1","1","3","2"};
//    static String[] pantry_time ={"3 Days","2 Days","4 Days","2 Days","1 Days","2 Days"};

    static ArrayList<Uri> pantry_img=new ArrayList<Uri>();

    static ArrayList<String> pantry_name =new ArrayList<String>();

    static ArrayList<String> pantry_qut =new ArrayList<String>();

    static ArrayList<String> pantry_time =new ArrayList<String>();



    static void addPantryImage(Uri ImageUri) {
        pantry_img.add(Uri.parse("android.resource://your.package.name/" + R.drawable.lettuce));
        pantry_img.add(Uri.parse("android.resource://your.package.name/" + R.drawable.carrots));
        pantry_img.add(Uri.parse("android.resource://your.package.name/" + R.drawable.chicken));
        
        pantry_img.add(ImageUri);
    }

    static void addPantry(String name, String qut, String time){

        pantry_name.add("Lettuce");
        pantry_name.add("Carrot");
        pantry_name.add("Whole Chicken");

        pantry_qut.add("3");
        pantry_qut.add("4");
        pantry_qut.add("1");

        pantry_time.add("4");
        pantry_time.add("2");
        pantry_time.add("1");

        //add ing

        pantry_time.add(name);
        pantry_qut.add(qut);
        pantry_time.add(time);


    }

}
