package com.example.savethefood;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

public class purchase_dashboard extends AppCompatActivity {

    RecyclerView rv_delivery;

    int[] customer_img=database.customer_img;
    String[] customer_name =database.customer_name;
    String[] customer_restaurant =database.customer_restaurant;
    String[] customer_price =database.customer_price;
    String[] customer_location =database.customer_location;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_purchase_dashboard);


        rv_delivery=(RecyclerView) findViewById(R.id.rv_f1_pr);

        rv_delivery.setLayoutManager(new GridLayoutManager(purchase_dashboard.this,1));
        rv_delivery.setAdapter(new rv_adapter_customer(customer_img,customer_name,customer_restaurant,customer_price,customer_location,purchase_dashboard.this));


    }
}