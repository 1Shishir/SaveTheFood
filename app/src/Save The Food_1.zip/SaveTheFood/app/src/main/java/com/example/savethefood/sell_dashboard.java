package com.example.savethefood;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

public class sell_dashboard extends AppCompatActivity {

    RecyclerView rv_delivery;

    int[] delivery_img=database.delivery_img;
    String[] delivery_name =database.delivery_name;
    String[] delivery_restaurant =database.delivery_restaurant;
    String[] delivery_price =database.delivery_price;
    String[] delivery_location =database.delivery_location;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sell_dashboard);

        rv_delivery=(RecyclerView) findViewById(R.id.rv_f1_sell);

        rv_delivery.setLayoutManager(new GridLayoutManager(sell_dashboard.this,1));
        rv_delivery.setAdapter(new rv_adapter_deliverable(delivery_img,delivery_name,delivery_restaurant,delivery_price,delivery_location,sell_dashboard.this));


    }
}