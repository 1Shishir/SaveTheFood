package com.example.savethefood;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentResolver;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

public class sign_up extends AppCompatActivity {
    Button signup_button;
    TextInputEditText signup_fname;
    TextInputEditText signup_lname;
    TextInputEditText signup_email;
    TextInputEditText signup_password;

    TextInputEditText signup_phone;
    TextInputEditText signup_address;

    String first_name="";
    String last_name="";
    String phone_number="";
    String my_address="";

    Uri uri;

    String email;
    String password;

    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);


        mAuth = FirebaseAuth.getInstance();

        signup_button=(Button) findViewById(R.id.sign_signup);

        signup_fname=(TextInputEditText) findViewById(R.id.sign_fname);
        signup_lname=(TextInputEditText) findViewById(R.id.sign_lname);
        signup_email=(TextInputEditText) findViewById(R.id.sign_email);
        signup_password=(TextInputEditText) findViewById(R.id.sign_password);

        signup_phone=(TextInputEditText) findViewById(R.id.sign_phone);
        signup_address=(TextInputEditText) findViewById(R.id.sign_address);


//        uri=Uri.parse(ContentResolver.SCHEME_ANDROID_RESOURCE+"://"+
//                getResources().getResourcePackageName(R.drawable.ic_baseline_image_24)+
//                getResources().getResourceTypeName(R.drawable.ic_baseline_image_24)+
//                getResources().getResourceEntryName(R.drawable.ic_baseline_image_24));



        signup_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                email=signup_email.getText().toString();
                password=signup_password.getText().toString();

                signUpFireBAse(email,password);

            }
        });


    }

    private void uploadToFirebase() {

        first_name=signup_fname.getText().toString();
        last_name=signup_lname.getText().toString();

        phone_number=signup_phone.getText().toString();
        my_address=signup_address.getText().toString();

        if(phone_number.isEmpty()||first_name.isEmpty()||uri==null){
            Toast.makeText(sign_up.this, "Please Fill Required Field", Toast.LENGTH_SHORT).show();
        }

        else {
            //firebase upload
            FirebaseStorage storage = FirebaseStorage.getInstance();
            String uid = FirebaseAuth.getInstance().getUid().toString();
            StorageReference uploder = storage.getReference("profile").child(uid);



            uploder.putFile(uri).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                @Override
                public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {

                    uploder.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                        @Override
                        public void onSuccess(Uri uri) {

                            data_profile data_profile=new data_profile(my_address,first_name,uri.toString(),last_name,phone_number);

                            FirebaseDatabase db=FirebaseDatabase.getInstance();
                            DatabaseReference node =db.getReference("profile").child(uid);
                            node.setValue(data_profile);

                            signup_fname.setText("");
                            signup_lname.setText("");
                            signup_email.setText("");
                            signup_password.setText("");
                            signup_phone.setText("");
                            signup_address.setText("");

                            Toast.makeText(sign_up.this, "New user created", Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(sign_up.this,login.class));

                        }
                    });

                }
            });

        }

        }

    private void signUpFireBAse(String email,String password) {
       mAuth.createUserWithEmailAndPassword(email,password).addOnCompleteListener(sign_up.this, new OnCompleteListener<AuthResult>() {
           @Override
           public void onComplete(@NonNull Task<AuthResult> task) {

               if (task.isSuccessful()) {

                  // uploadToFirebase();
                   signup_fname.setText("");
                   signup_lname.setText("");
                   signup_email.setText("");
                   signup_password.setText("");
                   Toast.makeText(sign_up.this,"Sign up successful", Toast.LENGTH_SHORT).show();

                   startActivity(new Intent(sign_up.this,login.class));


               } else {
                   signup_fname.setText("");
                   signup_lname.setText("");
                   signup_email.setText("");
                   signup_password.setText("");

                   Toast.makeText(sign_up.this,"Sign up Failed", Toast.LENGTH_SHORT).show();

               }
           }
       });}


//    private void uploadToFirebase() {
//        firstName=signup_fname.getText().toString();
//        lastName=signup_lname.getText().toString();
//
//
//        data data=new data(firstName,lastName,email,password);
//
//    }


}