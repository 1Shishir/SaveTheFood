package com.example.savethefood;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class login extends AppCompatActivity {
Button login_button;
TextInputEditText login_email;
TextInputEditText login_password;

private FirebaseAuth mAuth;

String email,password;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        getSupportActionBar().hide();

        mAuth = FirebaseAuth.getInstance();

        login_email=(TextInputEditText) findViewById(R.id.login_email);
        login_password=(TextInputEditText) findViewById(R.id.login_password);
        login_button=(Button) findViewById(R.id.login_Login);

        login_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                email = login_email.getText().toString();
                password = login_password.getText().toString();

                //startActivity(new Intent(login.this, homePage.class));
                loginAuth(email, password);
            }

            private void loginAuth(String email, String password) {

                mAuth.signInWithEmailAndPassword(email,password).addOnCompleteListener(login.this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            login_email.setText("");
                            login_password.setText("");

                            startActivity(new Intent(login.this, homePage.class));


                        } else {
                            login_email.setText("");
                            login_password.setText("");

                            Toast.makeText(login.this, "Wrong Email or Password", Toast.LENGTH_SHORT).show();
                        }
                    }
                });

            }
        });





            }}
